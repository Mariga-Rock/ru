import { useState, useEffect, useRef, FormEvent } from 'react';
import {
  Layers,
  Users,
  FileSearch,
  ChevronRight,
  Mail,
  Linkedin,
  ArrowUpRight,
  CheckCircle,
  Menu,
  X,
  Briefcase,
  Target,
  TrendingUp,
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    document.querySelectorAll('.animate-on-scroll').forEach((el) => {
      observerRef.current?.observe(el);
    });

    return () => observerRef.current?.disconnect();
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <a href="#" className="text-xl font-bold text-gray-900">
              Design<span className="text-rose-600">Director</span>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#about" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">
                About
              </a>
              <a href="#services" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">
                Services
              </a>
              <a href="#case-studies" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">
                Case Studies
              </a>
              <a href="#testimonials" className="hidden text-gray-600 hover:text-gray-900 transition-colors font-medium">
                Testimonials
              </a>
              <a
                href="#contact"
                className="bg-rose-600 text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-rose-700 transition-all shadow-sm hover:shadow-md"
              >
                Get in Touch
              </a>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-gray-600"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t border-gray-100">
              <a href="#about" className="block py-2 text-gray-600 hover:text-gray-900 font-medium" onClick={() => setIsMenuOpen(false)}>
                About
              </a>
              <a href="#services" className="block py-2 text-gray-600 hover:text-gray-900 font-medium" onClick={() => setIsMenuOpen(false)}>
                Services
              </a>
              <a href="#case-studies" className="block py-2 text-gray-600 hover:text-gray-900 font-medium" onClick={() => setIsMenuOpen(false)}>
                Case Studies
              </a>
              <a href="#testimonials" className="hidden py-2 text-gray-600 hover:text-gray-900 font-medium" onClick={() => setIsMenuOpen(false)}>
                Testimonials
              </a>
              <a
                href="#contact"
                className="block mt-4 bg-rose-600 text-white px-5 py-2.5 rounded-lg font-semibold text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                Get in Touch
              </a>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero-gradient pt-28 pb-12 lg:pt-32 lg:pb-16 text-left min-h-[80vh] flex items-center">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
          <div className="max-w-4xl">
            <p className="text-rose-400 font-semibold tracking-wide uppercase mb-2 animate-on-scroll">
              US & APAC
            </p>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-tight mb-3 animate-on-scroll">
              Fractional Design Director for Enterprise B2B Products
            </h1>
            <p className="text-xl lg:text-2xl text-gray-300 mb-6 leading-relaxed max-w-3xl animate-on-scroll">
              Design systems, UX strategy, and team mentorship to scale your product without hiring full-time.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 animate-on-scroll">
              <a
                href="#contact"
                className="inline-flex items-center justify-center bg-white text-gray-900 px-6 py-3 rounded-lg font-semibold text-lg hover:bg-gray-50 transition-all shadow-lg hover:shadow-xl group"
              >
                Book a free call
                <ArrowUpRight className="ml-2 w-5 h-5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
              <a
                href="#case-studies"
                className="inline-flex items-center justify-center border-2 border-gray-400 text-white px-6 py-3 rounded-lg font-semibold text-lg hover:bg-gray-400/10 transition-all"
              >
                View case studies
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-14 lg:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <h2 className="text-sm font-semibold text-rose-600 uppercase tracking-wide mb-3 animate-on-scroll">
                About
              </h2>
              <h3 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6 animate-on-scroll">
                20+ Years of Shipping Enterprise Products
              </h3>
              <div className="space-y-4 text-gray-600 text-lg leading-relaxed animate-on-scroll">
                <p>
                  Enterprise-grade design systems and UX strategy — I help you scale your product and
                  teams faster, with fewer iterations. No full-time commitment required.
                </p>
                <p>
                  After 10+ years of designing complex B2B systems for US enterprises, I'm now focusing
                  on helping APAC startups and scale-ups build world-class design infrastructure.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-1 gap-6 animate-on-scroll">
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <div className="text-4xl lg:text-5xl font-bold text-rose-600 mb-2">10+</div>
                <div className="text-gray-500 font-medium">Design systems built</div>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <div className="text-4xl lg:text-5xl font-bold text-rose-600 mb-2">50+</div>
                <div className="text-gray-500 font-medium">Products shipped</div>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <div className="text-4xl lg:text-5xl font-bold text-rose-600 mb-2">15+</div>
                <div className="text-gray-500 font-medium">Led teams of this size</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-14 lg:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-10">
            <h2 className="text-sm font-semibold text-rose-600 uppercase tracking-wide mb-3 animate-on-scroll">
              Services
            </h2>
            <h3 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4 animate-on-scroll">
              How I Can Help Your Business
            </h3>
            <p className="text-gray-600 text-lg animate-on-scroll">
              Strategic design leadership tailored to your stage and needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Service Card 1 */}
            <div className="group bg-gray-50 rounded-2xl p-6 lg:p-8 border border-gray-100 hover:border-rose-200 hover:shadow-xl transition-all duration-300 animate-on-scroll">
              <div className="w-12 h-12 bg-rose-100 rounded-xl flex items-center justify-center mb-5 group-hover:bg-rose-600 transition-colors">
                <Layers className="w-7 h-7 text-rose-600 group-hover:text-white transition-colors" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">
                Design System as a Service
              </h4>
              <p className="text-gray-600 leading-relaxed mb-6">
                Audit, build, and implement a scalable design system with code components. Establish
                consistent design language across your product suite.
              </p>
              <a
                href="#contact"
                className="inline-flex items-center text-rose-600 font-semibold hover:text-rose-700 transition-colors group/link"
              >
                Learn more
                <ChevronRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
              </a>
            </div>

            {/* Service Card 2 */}
            <div className="group bg-gray-50 rounded-2xl p-6 lg:p-8 border border-gray-100 hover:border-rose-200 hover:shadow-xl transition-all duration-300 animate-on-scroll">
              <div className="w-12 h-12 bg-rose-100 rounded-xl flex items-center justify-center mb-5 group-hover:bg-rose-600 transition-colors">
                <Users className="w-7 h-7 text-rose-600 group-hover:text-white transition-colors" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">
                Fractional Design Director
              </h4>
              <p className="text-gray-600 leading-relaxed mb-6">
                10-20 hrs/week of strategic leadership, team reviews, and roadmap planning.
                Part-time executive leadership without full-time cost.
              </p>
              <a
                href="#contact"
                className="inline-flex items-center text-rose-600 font-semibold hover:text-rose-700 transition-colors group/link"
              >
                Learn more
                <ChevronRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
              </a>
            </div>

            {/* Service Card 3 */}
            <div className="group bg-gray-50 rounded-2xl p-6 lg:p-8 border border-gray-100 hover:border-rose-200 hover:shadow-xl transition-all duration-300 animate-on-scroll">
              <div className="w-12 h-12 bg-rose-100 rounded-xl flex items-center justify-center mb-5 group-hover:bg-rose-600 transition-colors">
                <FileSearch className="w-7 h-7 text-rose-600 group-hover:text-white transition-colors" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">
                UX Audit & Roadmap
              </h4>
              <p className="text-gray-600 leading-relaxed mb-6">
                In-depth analysis of your B2B product with actionable recommendations.
                Identify quick wins and long-term improvements.
              </p>
              <a
                href="#contact"
                className="inline-flex items-center text-rose-600 font-semibold hover:text-rose-700 transition-colors group/link"
              >
                Learn more
                <ChevronRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Case Studies Section */}
      <section id="case-studies" className="py-14 lg:py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-10">
            <h2 className="text-sm font-semibold text-rose-400 uppercase tracking-wide mb-3 animate-on-scroll">
              Case Studies
            </h2>
            <h3 className="text-3xl lg:text-4xl font-bold text-white mb-4 animate-on-scroll">
              Proven Results Across Industries
            </h3>
            <p className="text-gray-300 text-lg animate-on-scroll">
              Selected projects from enterprise clients in fintech, logistics, and SaaS
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Case Study 1 */}
            <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700 hover:border-rose-500/50 transition-all animate-on-scroll">
              <div className="flex items-center gap-3 mb-4">
                <Briefcase className="w-5 h-5 text-rose-400" />
                <span className="text-sm text-rose-400 font-medium">Fintech</span>
              </div>
              <h4 className="text-xl font-bold text-white mb-3">
                High-Frequency Trading Platform
              </h4>
              <div className="space-y-3 text-sm">
                <div>
                  <span className="text-gray-400 font-medium">Challenge:</span>
                  <p className="text-gray-300 mt-1">
                    Legacy UI couldn't scale to support new asset classes
                  </p>
                </div>
                <div>
                  <span className="text-gray-400 font-medium">Approach:</span>
                  <p className="text-gray-300 mt-1">
                    Built modular design system with real-time data visualization components
                  </p>
                </div>
                <div>
                  <span className="text-gray-400 font-medium">Result:</span>
                  <p className="text-gray-300 mt-1">
                    40% faster feature development, 60% reduction in UI bugs
                  </p>
                </div>
              </div>
            </div>

            {/* Case Study 2 */}
            <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700 hover:border-rose-500/50 transition-all animate-on-scroll">
              <div className="flex items-center gap-3 mb-4">
                <Target className="w-5 h-5 text-rose-400" />
                <span className="text-sm text-rose-400 font-medium">Logistics</span>
              </div>
              <h4 className="text-xl font-bold text-white mb-3">
                Enterprise Fleet Management
              </h4>
              <div className="space-y-3 text-sm">
                <div>
                  <span className="text-gray-400 font-medium">Challenge:</span>
                  <p className="text-gray-300 mt-1">
                    Disparate tools created workflow friction for operations teams
                  </p>
                </div>
                <div>
                  <span className="text-gray-400 font-medium">Approach:</span>
                  <p className="text-gray-300 mt-1">
                    Unified 5 legacy systems into single dashboard with role-based views
                  </p>
                </div>
                <div>
                  <span className="text-gray-400 font-medium">Result:</span>
                  <p className="text-gray-300 mt-1">
                    35% productivity gain, 50% reduction in training time
                  </p>
                </div>
              </div>
            </div>

            {/* Case Study 3 */}
            <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700 hover:border-rose-500/50 transition-all animate-on-scroll">
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className="w-5 h-5 text-rose-400" />
                <span className="text-sm text-rose-400 font-medium">SaaS</span>
              </div>
              <h4 className="text-xl font-bold text-white mb-3">
                B2B Analytics Dashboard
              </h4>
              <div className="space-y-3 text-sm">
                <div>
                  <span className="text-gray-400 font-medium">Challenge:</span>
                  <p className="text-gray-300 mt-1">
                    Complex data made insights difficult to discover and share
                  </p>
                </div>
                <div>
                  <span className="text-gray-400 font-medium">Approach:</span>
                  <p className="text-gray-300 mt-1">
                    Designed progressive disclosure patterns with customizable widgets
                  </p>
                </div>
                <div>
                  <span className="text-gray-400 font-medium">Result:</span>
                  <p className="text-gray-300 mt-1">
                    25% increase in DAU, NPS score improved from 32 to 68
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section / Footer */}
      <footer id="contact" className="py-14 lg:py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
            {/* Contact Info */}
            <div className="animate-on-scroll">
              <h2 className="text-sm font-semibold text-rose-400 uppercase tracking-wide mb-3">
                Contact
              </h2>
              <h3 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                Let's Build Something Great
              </h3>
              <p className="text-gray-300 text-lg leading-relaxed mb-8">
                Ready to elevate your product's design? Book a free 30-minute discovery call
                to discuss your challenges and see if we're a good fit.
              </p>

              <div className="space-y-4">
                <a
                  href="mailto:hello@designdirector.com"
                  className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors group"
                >
                  <Mail className="w-5 h-5 text-rose-400" />
                  <span>hello@designdirector.com</span>
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors group"
                >
                  <Linkedin className="w-5 h-5 text-rose-400" />
                  <span>Connect on LinkedIn</span>
                </a>
              </div>

              <div className="mt-10 pt-8 border-t border-gray-700">
                <p className="text-sm text-gray-400">
                  Serving startups and scale-ups across APAC.
                </p>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-gray-800/50 rounded-2xl p-6 lg:p-8 border border-gray-700 animate-on-scroll">
              {isSubmitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <CheckCircle className="w-16 h-16 text-rose-400 mb-4" />
                  <h4 className="text-xl font-semibold text-white mb-2">Message Sent!</h4>
                  <p className="text-gray-300">
                    I'll get back to you within 24-48 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-colors"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                      Message
                    </label>
                    <textarea
                      id="message"
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-colors resize-none"
                      placeholder="Tell me about your project..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-rose-600 text-white px-6 py-4 rounded-lg font-semibold text-lg hover:bg-rose-700 transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                  >
                    Book a free call
                    <ArrowUpRight className="w-5 h-5" />
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-gray-700 text-center text-sm text-gray-400">
            <p>&copy; 2024 DesignDirector. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
